import os
os.system('python main.py')