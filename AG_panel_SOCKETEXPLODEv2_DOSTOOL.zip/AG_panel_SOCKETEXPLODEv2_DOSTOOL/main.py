import json
import threading
import sys
import os  # Import the os module
from gui import controler
from attrs import access_file, menu_lang, hash_checked, read, write, color_gardient, green_gr, red_gr, update_pypi

languages = menu_lang()

def install_package(package):
    package_name = package.get('name', 'Unknown Package')  # Use .get to avoid KeyError
    try:
        exec(f"{package['import']}")
        print(f"\r\x1b[K\x1b[38;5;196mDONE \x1b[38;5;197mINSTALL \x1b[38;5;198m{package_name} \x1b[38;5;199mPIP!\x1b[0m")
    except:
        os.system(package['command'])
        print(f'\r\x1b[K\x1b[38;5;255m[\\x1b[38;5;196mDONE\\x1b[38;5;255m] \\x1b[38;5;226m{package_name} \\x1b[38;5;227m. . . . \\x1b[38;5;228mdone\\x1b[0m')

def is_update(file='update.json'):
    c = access_file(f'https://raw.githubusercontent.com/Tool-Free/socketexplodev2_assets/main/{file}')
    if not c:
        return
    c = c.replace(b',\n  }\n}', b'\n  }\n}')
    json_data = json.loads(c)
    pip_requirements = json_data['PIP']

    # Install packages without introducing delays
    for package in pip_requirements.values():
        install_package(package)

def main():
    is_update()
    content = access_file('https://raw.githubusercontent.com/Hex1629/SOCKETEXPLODEv2_DOSTOOL/main/status.txt', 'r')
    
    if content:
        if content.decode() == 'Default':
            print(color_gardient(languages['CHECK_MSG']['DEFAULT'], green_gr))
            controler()
        elif content.decode() == 'Shutdown':
            print(color_gardient(languages['CHECK_MSG']['SHUTDOWN'], red_gr))
            exit()
        else:
            status_data = content.decode().split(' ')
            if status_data[0] == 'Update':
                print(languages['CHECK_MSG']['REPORT'])
                is_update(status_data[1])
                print(languages['LOG']['DONE'])
                controler()

if __name__ == "__main__":
    main()
