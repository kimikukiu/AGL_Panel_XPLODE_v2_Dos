---
name: Feature
about: Add any feature
title: feature
labels: enhancement
assignees: Hex1629

---

TIME - [ Ex: RIGHT-NOW, NEXT-DAY, ANY-UPDATE ]

#

**Request for?** ( REQUIRE )
[ Ex: script.DOS, plugin.ping]

**Description for info about there problem now:** ( REQUIRE )
[ Ex: I want other methods for flood other isp ]

**Why want this feature?** ( REQUIRE )
[ Ex: new feature for tool ]

**Additional context**
Any context
